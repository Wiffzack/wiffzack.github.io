var searchword;
var  keywords;
var tabUrl;
var pdfsitenumber;
var resivedurl;
var run=0;

function readypage(){

// couse some strange things
var myobj = document.getElementById("loadcss");
myobj.remove();

function getCookie(name) {
  var value = "; " + document.cookie;
  var parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}



function checkhttp()
{
	if (window.XMLHttpRequest) {
		xmlhttp=new XMLHttpRequest();
	} else {
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
		xmlhttp.onreadystatechange=function() {
	if (this.readyState==4 && this.status==200) {
		//pass
	}
	}
}


function mysearch() {
    var txt;
    searchword = prompt("Please enter search term:", "");
    if (searchword == null || searchword == "") {
        txt = "User cancelled the prompt.";
    }
}

function myadd() {
    var txt;
    tabUrl = prompt("Please enter the page url:", "");
    if (tabUrl == null || tabUrl == "") {
    txt ="no input url";
    }else{
    keywords = prompt("Please write some keywords for the page:", "");
    if (keywords == null || keywords == "") {
        txt = "User cancelled the prompt.";
    } else {
		rating = prompt("Please give the page a rating (from 1-10) default:1", "");	
		if (rating == null || rating == "") {
			rating = 1;
		} else {
			//pass
		}
}
}
}


function sendcookierequest(){
	//alert("easy");
	resivedurl = [];
	//setTimeout(function(){}, 1000);
	try {
	resivedurl = (JSON.parse(decodeURIComponent( getCookie("acookie"))));
        if (resivedurl) {
	        getUrl();
        }
	}
	catch(err){
	window.open("https://wiffzackius.ddns.net:8443/login/main_login.php");
	}
	//window.open(resivedurl[0]);
	//setTimeout(function(){}, 500);
};		


function getUrl() {
        if (run){
		console.log("Already running");
	}else{
	run=1;
	checkhttp();
	var cookiename = "acookie";
	//checkhttp();
	//window.open("https://wiffzackius.ddns.net:8443/search_plugin.php?keywords="+encodeURIComponent(searchword));
        xmlhttp.open("GET","https://wiffzackius.ddns.net:8443/search_plugin.php?url="+encodeURIComponent(searchword),false);
        xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        //xmlhttp.timeout = 5000;
        xmlhttp.send();
	sendcookierequest();
	//window.open(resivedurl[0]);
	//var res = str.replace("http://","https://");
	url =  resivedurl[0];
	if (url.includes("http")){
	 window.open(resivedurl[0]);
	}else{
	window.open("https://"+resivedurl[0])
	}
	}
	run=0;
};

function sendCurrentUrl() {
	// this require pdf.js extension!
	checkhttp();
	if(pdfsitenumber){
		tabUrl = pdfurl;
		pagenumber = pdfsitenumber;
	}else{
		var pagenumber = 1;
	}
	xmlhttp.open("GET","https://wiffzackius.ddns.net:8443/foobar_submit.php?url="+encodeURIComponent(tabUrl)+"&"+"keywords="+encodeURIComponent(keywords)+"&"+"rating="+encodeURIComponent(rating)+"&"+"pagenumber="+encodeURIComponent(pagenumber),true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.timeout = 5000;
	xmlhttp.send();
	}


document.getElementById("searcher").addEventListener("click", klicksearch);

document.getElementById("adder").addEventListener("click", klickadd);




function klickadd(){
        myadd();
        if ( keywords) {
                sendCurrentUrl();
        }
}


function klicksearch(){
        mysearch();
        if (searchword) {
                getUrl();
        }
}


document.addEventListener('keypress', eventKey);

function eventKey(e) {
	if(e.code=="Digit1"){
		mysearch();
		if (searchword) {
			getUrl();
		}
	}
}
}
document.addEventListener("DOMContentLoaded", readypage);
