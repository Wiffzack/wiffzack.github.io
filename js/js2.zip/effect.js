var bname=getBrowserName(),sysn=getOSName();bname.includes("Internet");bname.includes("Chrome");bname.includes("Safari");bname.includes("Firefox");
