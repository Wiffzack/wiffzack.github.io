
var bname=getBrowserName();
var sysn=getOSName();

//string.includes(substring)
if (bname.includes("Internet")){

}
if (bname.includes("Chrome")){
//alert("")
}
if (bname.includes("Safari")){

}
if (bname.includes("Firefox")){

}
